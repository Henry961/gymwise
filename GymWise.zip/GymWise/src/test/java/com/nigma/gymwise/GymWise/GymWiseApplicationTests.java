package com.nigma.gymwise.GymWise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymWiseApplicationTests {

	@Test
	void contextLoads() {
	}

}
