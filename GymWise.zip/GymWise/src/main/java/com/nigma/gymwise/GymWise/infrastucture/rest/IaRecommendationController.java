package com.nigma.gymwise.GymWise.infrastucture.rest;

public class IaRecommendationController {



}
