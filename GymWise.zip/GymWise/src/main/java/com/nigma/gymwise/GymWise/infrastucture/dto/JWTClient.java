package com.nigma.gymwise.GymWise.infrastucture.dto;

public record JWTClient(String token) {
}
