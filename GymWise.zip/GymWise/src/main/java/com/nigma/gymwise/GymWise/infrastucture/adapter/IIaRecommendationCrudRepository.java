package com.nigma.gymwise.GymWise.infrastucture.adapter;

import com.nigma.gymwise.GymWise.infrastucture.entity.IaRecommendationEntity;
import org.springframework.data.repository.CrudRepository;

public interface IIaRecommendationCrudRepository extends CrudRepository<IaRecommendationEntity, Integer> {
}
