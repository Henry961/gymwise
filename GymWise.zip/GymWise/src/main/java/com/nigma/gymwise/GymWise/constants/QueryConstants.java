package com.nigma.gymwise.GymWise.constants;

public class QueryConstants {

    public static final String userFindEmailDateExpired = "SELECT email FROM UserProfileEntity";

    private QueryConstants(){}

}
