package com.nigma.gymwise.GymWise.infrastucture.dto;

public record UserDTO(String username, String password) {
}
